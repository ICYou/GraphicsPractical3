Jozef Siu & Ruben Verboon
4290216 - 4227980

B)
As for the division of workload, we mostly did the assignments together while skyping and sharing articles, links, screenshots and code.

C)
http://stackoverflow.com/questions/3294176/apply-post-render-effect-to-spritebatch-in-xna
http://www.gamedev.net/topic/618958-anti-aliasing-techniques/
http://gamedev.stackexchange.com/questions/34582/how-do-i-use-screen-space-derivatives-to-antialias-a-parametric-shape-in-a-pixel
http://dev.theomader.com/gaussian-kernel-calculator/
http://www.dhpoware.com/demos/xnaGaussianBlur.html#_blank

D) 
We have implemented E1 multiple light sources, E3 Cell shading, E5 Color filter, E6 Gaussian Blur.
You can cycle through our implementations by pressing the 'space' button, you can also use the arrow buttons to move the camera.
Unfortunately we weren't able to implement anti aliasing succesfully at E3
